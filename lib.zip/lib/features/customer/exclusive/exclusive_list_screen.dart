import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/repositories/home_repository.dart';
import '../../../models/product.dart';
import '../widgets/exclusive_card.dart';
import '../home/widgets/nav_bar.dart';
import '../home/home_footer.dart';
import '../../../app/routes.dart';

class ExclusiveListScreen extends StatefulWidget {
  const ExclusiveListScreen({super.key});

  @override
  State<ExclusiveListScreen> createState() => _ExclusiveListScreenState();
}

class _ExclusiveListScreenState extends State<ExclusiveListScreen> {
  List<ExclusiveProduct> _products = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final products = await HomeRepository.getExclusiveProducts();
    if (mounted) {
      setState(() {
        _products = products;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 768;

    return Scaffold(
      backgroundColor: AppTheme.background,
      endDrawer: const NavDrawer(),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 120),
                Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: isMobile ? 24 : 80,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Exclusive Collection',
                        style: GoogleFonts.playfairDisplay(
                          fontSize: isMobile ? 32 : 48,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textDark,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Discover our limited edition masterpieces, handcrafted with precision and passion.',
                        style: GoogleFonts.jost(
                          fontSize: 16,
                          color: AppTheme.textLight,
                        ),
                      ),
                      const SizedBox(height: 56),
                      _isLoading
                          ? const Center(child: CircularProgressIndicator(color: AppTheme.primaryBrown))
                          : _products.isEmpty
                              ? _buildEmptyState()
                              : _buildGrid(isMobile),
                      const SizedBox(height: 100),
                    ],
                  ),
                ),
                const HomeFooter(),
              ],
            ),
          ),
          const Positioned(top: 0, left: 0, right: 0, child: NavBar()),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        children: [
          const Icon(Icons.star_outline, size: 64, color: AppTheme.divider),
          const SizedBox(height: 16),
          Text('No exclusive pieces found.', style: AppTheme.bodyLarge),
        ],
      ),
    );
  }

  Widget _buildGrid(bool isMobile) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _products.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isMobile ? 1 : 3,
        childAspectRatio: 0.72,
        crossAxisSpacing: 32,
        mainAxisSpacing: 48,
      ),
      itemBuilder: (context, index) {
        return ExclusiveCard(
          product: _products[index],
          onTap: () => Navigator.pushNamed(
            context,
            Routes.exclusiveDetail,
            arguments: _products[index],
          ),
        );
      },
    );
  }
}
